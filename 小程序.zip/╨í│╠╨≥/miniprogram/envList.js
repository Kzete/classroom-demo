const envList = [{"envId":"cloud1-6gfa7ufob68ff92a","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}